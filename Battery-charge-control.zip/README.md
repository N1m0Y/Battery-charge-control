## Battery Charge Control

Prolong battery life by controlling the voltage XD

Current compatibility: Leeco Le pro 3 100%

[More info here](http://batteryuniversity.com/learn/article/how_to_prolong_lithium_based_batteries)

[Androidiani Thread]()

[XDA Thread]()
